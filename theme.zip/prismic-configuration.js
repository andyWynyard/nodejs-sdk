
      module.exports = {

        apiEndpoint: 'https://your-repo-name.prismic.io/api',
      
        linkResolver: function(doc, ctx) {
          if (doc.type == 'page') return '/page/' + doc.uid;
          return '/';
        }
      };
    